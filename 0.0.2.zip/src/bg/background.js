// if you checked "fancy-settings" in extensionizr.com, uncomment this lines

//var settings = new Store("settings", {
//	"sample_setting": "This is how you use Store.js to remember values"
//});

//example of using a message handler from the inject scripts
chrome.extension.onMessage.addListener(
	function (request, sender, sendResponse) {
		if (request.newIconPath !== undefined) changeIcon(request.newIconPath, sender);

		sendResponse();
	});


function changeIcon(val, sender) {
	var icon = val === 'attach' ? "icons/icon48u.png" : "icons/icon48.png";
	chrome.browserAction.setIcon({
		path: icon,
		tabId: sender.tab.id
	});
}